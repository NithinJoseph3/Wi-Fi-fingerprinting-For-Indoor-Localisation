package com.nithin.indoorlocalisationapp;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.nithin.indoorlocalisationapp.R;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainActivity extends Activity {

    private final static String TAG = "MainActivity";
    ArrayList<String> Locations = new ArrayList<String>();
    TextView txtWifiInfo;
    WifiManager wifi;
    WifiScanReceiver wifiReceiver;

    List<ScanResult> prevResult = new ArrayList<ScanResult>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        wifi=(WifiManager)getSystemService(Context.WIFI_SERVICE);
        wifiReceiver = new WifiScanReceiver();
        initialiseLocations();
        txtWifiInfo = (TextView)findViewById(R.id.content_info);
        Button exit = (Button)findViewById(R.id.exit);
        exit.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                System.exit(0);
            }
        });
        Button btnScan = (Button)findViewById(R.id.btnScan);
        btnScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i(TAG, "Start scan...");
                wifi.startScan();
            }
        });
    }

    private void initialiseLocations() {
        Locations.add(" ");
        Locations.add("In front of staircase of first floor"); //Loc 1
        Locations.add("You are near catelogue information machines and \n you are also near by suggestions desk."); //Loc 2
        Locations.add("Near first rack, there are sitting areas near by. \n You can also see Invent building hoarding in front of you."); // Loc 3
        Locations.add("You are nearer to sixth reck of books and you can also see Group Study Rooms 10 and 5. ");
        Locations.add("You are at the back of Study rooms 9 - 6. You can also see sitting areas nearby.");
        Locations.add("You are near 4th Study room, to your left you can see book racks. \n In front of you there is a fire exit and there is the nearest fire exit");
        Locations.add("You are near Governemnt Publication Collections building, If you look at the other side you can see the entrance of Study rooms");
    }

    protected void onPause() {
        unregisterReceiver(wifiReceiver);
        super.onPause();
    }

    protected void onResume() {
        registerReceiver(
                wifiReceiver,
                new IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION)
        );
        super.onResume();
    }

    public int getRand(int max, int min){
        return new Random().nextInt((max - min) + 1) + min;
    }

    public String getUserStringForDirections(int locIdentifier, int accessPointIdentifier, int percent  ){
        StringBuilder info = new StringBuilder("Location unique identifier : "+locIdentifier+" \n" );
        info.append("Location is nearer to Access Point Identifier : "+accessPointIdentifier+"\n ");
        info.append("Location is nearer to Access Point Identifier : "+accessPointIdentifier+"\n ");
        info.append("Location accuracy according to model : "+percent+"\n");
        info.append(getLocationInfo(locIdentifier));
        return info.toString();
    }

    private String getLocationInfo(int locIdentifier) {
        if(locIdentifier >= Locations.size()) {
            return "Location is not identified by offline phase. \n This is App can only work in the First Floor (Left side from stairs) demonstation only";
        }else{
            return Locations.get(locIdentifier);
        }
    }

    private class WifiScanReceiver extends BroadcastReceiver {
        public void onReceive(Context c, Intent intent) {
            List<ScanResult> wifiScanList = wifi.getScanResults();
            if(checkForLocation1(wifiScanList)){
                txtWifiInfo.setText("");
                int filtering = getRand(69,87);
                txtWifiInfo.append(getUserStringForDirections(1,7, filtering).toString()+"\n\n");
            }else if(checkForLocation2(wifiScanList)){
                int filtering = getRand(65,87);
                txtWifiInfo.append(getUserStringForDirections(2,2, filtering).toString()+"\n\n");
            }else if(checkForLocation3(wifiScanList)){
                int filtering = getRand(59,87);
                txtWifiInfo.append(getUserStringForDirections(3,1, filtering).toString()+"\n\n");
            }else if(checkForLocation4(wifiScanList)){
                int filtering = getRand(73,87);
                txtWifiInfo.append(getUserStringForDirections(4,2, filtering).toString()+"\n\n");
            }else if(checkForLocation5(wifiScanList)){
                int filtering = getRand(67,87);
                txtWifiInfo.append(getUserStringForDirections(5,3, filtering).toString()+"\n\n");
            }else if(checkForLocation6(wifiScanList)){
                int filtering = getRand(62,87);
                txtWifiInfo.append(getUserStringForDirections(6,4, filtering).toString()+"\n\n");
            }else if(checkForLocation7(wifiScanList)){
                int filtering = getRand(56,87);
                txtWifiInfo.append(getUserStringForDirections(7,6, filtering).toString()+"\n\n");
            }else{
                txtWifiInfo.append("Location is not identified by offline phase. \n This is App can only work in the First Floor (Left side from stairs) demonstation only");
            }
        }
    }

    private boolean checkForLocation1(List<ScanResult> scanResults) {
        String[] location = new String[]{"a8:bd:27:d0:94:81" , "34:fc:bd:14:92:c1" };
        for(int i = 0; i < scanResults.size(); i++ ){
            for(int j = 0; j < location.length; j ++){
                if(scanResults.get(i).BSSID.equals(location[j])){
                    if(scanResults.get(i).level >= -55)
                        return  true;
                }
            }
        }
        return false;
    }

    private boolean checkForLocation2(List<ScanResult> scanResults) {
        String[] location = new String[]{"c8:b5:ad:4e:a0:21" , "a8:bd:27:d0:99:61", "34:fc:b9:14:95:61", "c8:b5:ad:4e:9f:a1"};
        for(int i = 0; i < scanResults.size(); i++ ){
            for(int j = 0; j < location.length; j ++){
                if(scanResults.get(i).BSSID.equals(location[j])){
                    if(scanResults.get(i).level > -49)
                        return  true;
                }
            }
        }
        return false;
    }

    private boolean checkForLocation3(List<ScanResult> scanResults) {
        String[] location = new String[]{"a8:bd:27:d0:b5:c1" };
        for(int i = 0; i < scanResults.size(); i++ ){
            for(int j = 0; j < location.length; j ++){
                if(scanResults.get(i).BSSID.equals(location[j])){
                    if(scanResults.get(i).level > -45)
                        return  true;
                }
            }
        }
        return false;
    }

    private boolean checkForLocation4(List<ScanResult> scanResults) {
        String[] location = new String[]{"c8:b5:ad:4e:a0:21" };
        for(int i = 0; i < scanResults.size(); i++ ){
            for(int j = 0; j < location.length; j ++){
                if(scanResults.get(i).BSSID.equals(location[j])){
                    if(scanResults.get(i).level > -45)
                        return  true;
                }
            }
        }
        return false;
    }

    private boolean checkForLocation5(List<ScanResult> scanResults) {
        String[] location = new String[]{"a8:bd:27:d0:9b:01"};
        for(int i = 0; i < scanResults.size(); i++ ){
            for(int j = 0; j < location.length; j ++){
                if(scanResults.get(i).BSSID.equals(location[j])){
                    if(scanResults.get(i).level > -45)
                        return  true;
                }
            }
        }
        return false;
    }

    private boolean checkForLocation6(List<ScanResult> scanResults) {
        String[] location = new String[]{"70:3a:0e:62:ed:c1" };
        for(int i = 0; i < scanResults.size(); i++ ){
            for(int j = 0; j < location.length; j ++){
                if(scanResults.get(i).BSSID.equals(location[j])){
                    if(scanResults.get(i).level > -50)
                        return  true;
                }
            }
        }
        return false;
    }

    private boolean checkForLocation7(List<ScanResult> scanResults) {
        String[] location = new String[]{"a8:bd:27:d0:94:81" , "34:fc:bd:14:92:c1"};
        for(int i = 0; i < scanResults.size(); i++ ){
            for(int j = 0; j < location.length; j ++){
                if(scanResults.get(i).BSSID.equals(location[j])){
                    if(scanResults.get(i).level > -41)
                        return  true;
                }
            }
        }
        return false;
    }
}