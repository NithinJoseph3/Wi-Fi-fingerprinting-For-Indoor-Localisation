import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class WiFiMacAddrClassifier {


    public static void main(String[] args) throws IOException {
        List<String> macAddAlreadyExists = new ArrayList<>();
        String cvsSplitBy = ",";
        int lineCounter= -1;
        String[] mac;
        File file = new File("/Users/nithinjoseph/IdeaProjects/ClassifyingWifiMacAdresses/src/wifitracker.csv");
        FileReader fr = new FileReader(file);
        try(BufferedReader br = new BufferedReader(fr)) {
            for(String line; (line = br.readLine()) != null; ) {
                lineCounter++;
                mac = line.split(cvsSplitBy);
                if(macAddAlreadyExists.isEmpty()){
                    macAddAlreadyExists.add(lineCounter, mac[1]);
                }else{
                    for (int i = 0 ; i < macAddAlreadyExists.size(); i++) {
                        if(macAddAlreadyExists.contains(mac[1])){
                            //do nothing
                            System.out.println("match found \n");
                        }else{
                            macAddAlreadyExists.add(i, mac[1]);
                        }
                    }
                }
            }
        }
        String tmp = macAddAlreadyExists.toString();
        PrintWriter pw = new PrintWriter(new FileOutputStream("macadressclass"));
        pw.write(tmp);
        pw.close();
        System.out.println("Unique mac adderess are "+macAddAlreadyExists.size());
    }
    public void save(String fileName) throws FileNotFoundException {

    }
}
