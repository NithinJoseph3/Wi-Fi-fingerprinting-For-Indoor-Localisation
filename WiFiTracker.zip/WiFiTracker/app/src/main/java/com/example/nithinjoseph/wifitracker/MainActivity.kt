package com.example.nithinjoseph.wifitracker

import android.content.Context
import android.net.wifi.WifiManager
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.net.wifi.WifiInfo
import android.widget.Toast
import android.R.attr.level
import android.support.v7.app.AlertDialog
import android.content.DialogInterface
import android.R.string.cancel
import android.app.Activity


class MainActivity : Activity() {
    var btn : Button?= null
    var signalLevel = ArrayList<Int>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        btn = findViewById(R.id.button_get_signal)
        btn!!.setOnClickListener{
            val wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val wifiScanResultList = wifiManager.scanResults
            for (result in wifiScanResultList) {
                 signalLevel.add(result.level)
            }
            val builder = AlertDialog.Builder(this)
            builder.setMessage(signalLevel.toString())
            builder.create()
            builder.show()
        }
    }
}
